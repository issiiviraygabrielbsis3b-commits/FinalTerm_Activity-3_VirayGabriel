namespace InventoryApp;

public partial class RegisterForm : Form
{
    public string RegisteredUsername { get; private set; } = "";

    public RegisterForm()
    {
        InitializeComponent();
    }

    private void btnRegister_Click(object? sender, EventArgs e)
    {
        var fullName = txtFullName.Text.Trim();
        var username = txtUser.Text.Trim();
        var password = txtPass.Text;

        string? problem = null;
        if (fullName.Length == 0 || username.Length == 0) problem = "Full name and username are required.";
        else if (username.Length < 3) problem = "Username must be at least 3 characters.";
        else if (password.Length < 6) problem = "Password must be at least 6 characters.";
        else if (password != txtConfirm.Text) problem = "Passwords do not match.";

        if (problem is not null)
        {
            MessageBox.Show(problem, "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!UserRepository.Register(username, fullName, password, out var error))
        {
            MessageBox.Show(error, "Register", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        MessageBox.Show("Account created! You can now log in.", "Register",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        RegisteredUsername = username;
        DialogResult = DialogResult.OK;
    }

    private void RegisterForm_Load(object sender, EventArgs e)
    {

    }
}
