namespace InventoryApp;

public partial class SignInForm : Form
{
    public User? LoggedInUser { get; private set; }

    public SignInForm()
    {
        InitializeComponent();
    }

    private void btnLogin_Click(object? sender, EventArgs e)
    {
        var username = txtUser.Text.Trim();
        var password = txtPass.Text;

        if (username.Length == 0 || password.Length == 0)
        {
            MessageBox.Show("Please enter your username and password.", "Login",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var user = UserRepository.Authenticate(username, password);
        if (user is null)
        {
            MessageBox.Show("Invalid username or password.", "Login failed",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtPass.Clear();
            txtPass.Focus();
            return;
        }

        LoggedInUser = user;
        DialogResult = DialogResult.OK;
    }

    private void linkRegister_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
    {
        using var reg = new RegisterForm();
        if (reg.ShowDialog(this) == DialogResult.OK)
        {
            txtUser.Text = reg.RegisteredUsername;
            txtPass.Clear();
            txtPass.Focus();
        }
    }
}
