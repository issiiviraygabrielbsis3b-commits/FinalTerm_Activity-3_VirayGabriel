using System.Data.OleDb;

namespace InventoryApp;

public static class UserRepository
{
    public static bool Register(string username, string fullName, string password, out string error)
    {
        error = "";
        using var conn = Db.Open();

        using (var exists = Db.Command(conn, "SELECT COUNT(*) FROM Users WHERE Username = ?",
                   (OleDbType.VarWChar, username)))
        {
            if (Convert.ToInt32(exists.ExecuteScalar()) > 0)
            {
                error = "That username is already taken.";
                return false;
            }
        }

        using var insert = Db.Command(conn, "INSERT INTO Users (Username, FullName, PasswordHash) VALUES (?, ?, ?)",
            (OleDbType.VarWChar, username), (OleDbType.VarWChar, fullName),
            (OleDbType.LongVarWChar, PasswordHelper.Hash(password)));
        insert.ExecuteNonQuery();
        return true;
    }

    public static User? Authenticate(string username, string password)
    {
        using var conn = Db.Open();
        using var cmd = Db.Command(conn, "SELECT Username, FullName, PasswordHash FROM Users WHERE Username = ?",
            (OleDbType.VarWChar, username));
        using var r = cmd.ExecuteReader();
        if (!r.Read()) return null;

        var hash = Db.Str(r, 2);
        return PasswordHelper.Verify(password, hash)
            ? new User(Db.Str(r, 0), Db.Str(r, 1))
            : null;
    }
}
