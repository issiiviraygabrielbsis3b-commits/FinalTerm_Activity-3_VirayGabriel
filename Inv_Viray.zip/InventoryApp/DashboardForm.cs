namespace InventoryApp;





public partial class DashboardForm : Form
{
    public bool LoggedOut { get; private set; }

    public DashboardForm(User user)
    {
        InitializeComponent();

        lblWelcome.Text = $"WELCOME {user.DisplayName.ToUpperInvariant()}!";

        
        btnNavDashboard.BackColor = Color.FromArgb(74, 20, 140);

        
        lblTotalValue.Text = "125";
        lblInStockValue.Text = "94";
        lblLowStockValue.Text = "14";
        lblSuppliersValue.Text = "8";

        
        grid.Rows.Add("001", "Keyboard", "Accessories", 25, "$500", "Tech Solutions");
        grid.Rows.Add("002", "Mouse", "Accessories", 18, "$350", "Tech Solutions");
        grid.Rows.Add("003", "Monitor", "Electronics", 7, "$5,000", "Visor Corp");
        grid.Rows.Add("004", "CPU", "Components", 3, "$8,000", "Nova Tech");
        grid.Rows.Add("005", "RAM 8GB", "Components", 15, "$1,200", "Nova Tech");
        grid.ClearSelection();

        
        AddLowStock("Monitor", 7);
        AddLowStock("CPU", 3);
        AddLowStock("Webcam", 4);
    }

    private void AddLowStock(string name, int pcs)
    {
        var item = new ListViewItem(name);
        item.SubItems.Add($"{pcs}pcs");
        lowList.Items.Add(item);
    }

    
    private void btnLogout_Click(object? sender, EventArgs e)
    {
        LoggedOut = true;
        Close();
    }
}
