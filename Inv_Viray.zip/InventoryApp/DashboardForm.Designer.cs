#nullable enable
namespace InventoryApp
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer? components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle gridHeaderStyle = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle gridCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle tableGridHeaderStyle = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle tableGridCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnNavDashboard = new System.Windows.Forms.Button();
            this.btnNavProducts = new System.Windows.Forms.Button();
            this.btnNavCategories = new System.Windows.Forms.Button();
            this.btnNavSuppliers = new System.Windows.Forms.Button();
            this.btnNavTransaction = new System.Windows.Forms.Button();
            this.btnNavReports = new System.Windows.Forms.Button();
            this.btnNavSettings = new System.Windows.Forms.Button();
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.lblTotalValue = new System.Windows.Forms.Label();
            this.lblTotalCaption = new System.Windows.Forms.Label();
            this.cardTotalBody = new System.Windows.Forms.Panel();
            this.cardTotalStrip = new System.Windows.Forms.Panel();
            this.cardTotal = new System.Windows.Forms.Panel();
            this.lblInStockValue = new System.Windows.Forms.Label();
            this.lblInStockCaption = new System.Windows.Forms.Label();
            this.cardInStockBody = new System.Windows.Forms.Panel();
            this.cardInStockStrip = new System.Windows.Forms.Panel();
            this.cardInStock = new System.Windows.Forms.Panel();
            this.lblLowStockValue = new System.Windows.Forms.Label();
            this.lblLowStockCaption = new System.Windows.Forms.Label();
            this.cardLowStockBody = new System.Windows.Forms.Panel();
            this.cardLowStockStrip = new System.Windows.Forms.Panel();
            this.cardLowStock = new System.Windows.Forms.Panel();
            this.lblSuppliersValue = new System.Windows.Forms.Label();
            this.lblSuppliersCaption = new System.Windows.Forms.Label();
            this.cardSuppliersBody = new System.Windows.Forms.Panel();
            this.cardSuppliersStrip = new System.Windows.Forms.Panel();
            this.cardSuppliers = new System.Windows.Forms.Panel();
            this.tblCards = new System.Windows.Forms.TableLayoutPanel();
            this.pnlCardsHost = new System.Windows.Forms.Panel();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.pnlAddHost = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.pnlSearchHost = new System.Windows.Forms.Panel();
            this.lblProducts = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSupplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.grid = new System.Windows.Forms.DataGridView();
            this.pnlProducts = new System.Windows.Forms.Panel();
            this.btnQuickAdd = new System.Windows.Forms.Button();
            this.hostQuickAdd = new System.Windows.Forms.Panel();
            this.btnQuickStockIn = new System.Windows.Forms.Button();
            this.hostQuickStockIn = new System.Windows.Forms.Panel();
            this.btnQuickStockOut = new System.Windows.Forms.Button();
            this.hostQuickStockOut = new System.Windows.Forms.Panel();
            this.btnQuickReport = new System.Windows.Forms.Button();
            this.hostQuickReport = new System.Windows.Forms.Panel();
            this.lblQuick = new System.Windows.Forms.Label();
            this.pnlQuick = new System.Windows.Forms.Panel();
            this.colLowName = new System.Windows.Forms.ColumnHeader();
            this.colLowStock = new System.Windows.Forms.ColumnHeader();
            this.lowList = new System.Windows.Forms.ListView();
            this.lblLowTitle = new System.Windows.Forms.Label();
            this.linkViewAll = new System.Windows.Forms.LinkLabel();
            this.pnlLowHeader = new System.Windows.Forms.Panel();
            this.pnlLow = new System.Windows.Forms.Panel();
            this.pnlLowHost = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.pnlBody = new System.Windows.Forms.Panel();
            this.viewDashboard = new System.Windows.Forms.Panel();
            this.tableGrid = new System.Windows.Forms.DataGridView();
            this.lblTableTitle = new System.Windows.Forms.Label();
            this.viewTable = new System.Windows.Forms.Panel();
            this.pnlContent = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableGrid)).BeginInit();
            this.pnlSidebar.SuspendLayout();
            this.cardTotalBody.SuspendLayout();
            this.cardTotal.SuspendLayout();
            this.cardInStockBody.SuspendLayout();
            this.cardInStock.SuspendLayout();
            this.cardLowStockBody.SuspendLayout();
            this.cardLowStock.SuspendLayout();
            this.cardSuppliersBody.SuspendLayout();
            this.cardSuppliers.SuspendLayout();
            this.tblCards.SuspendLayout();
            this.pnlCardsHost.SuspendLayout();
            this.pnlAddHost.SuspendLayout();
            this.pnlSearchHost.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlProducts.SuspendLayout();
            this.hostQuickAdd.SuspendLayout();
            this.hostQuickStockIn.SuspendLayout();
            this.hostQuickStockOut.SuspendLayout();
            this.hostQuickReport.SuspendLayout();
            this.pnlQuick.SuspendLayout();
            this.pnlLowHeader.SuspendLayout();
            this.pnlLow.SuspendLayout();
            this.pnlLowHost.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.pnlBody.SuspendLayout();
            this.viewDashboard.SuspendLayout();
            this.viewTable.SuspendLayout();
            this.pnlContent.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnLogout.Size = new System.Drawing.Size(170, 46);
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnNavDashboard
            // 
            this.btnNavDashboard.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavDashboard.FlatAppearance.BorderSize = 0;
            this.btnNavDashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavDashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavDashboard.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavDashboard.ForeColor = System.Drawing.Color.White;
            this.btnNavDashboard.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavDashboard.Size = new System.Drawing.Size(170, 46);
            this.btnNavDashboard.Text = "Dashboard";
            this.btnNavDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavDashboard.UseVisualStyleBackColor = false;
            this.btnNavDashboard.Tag = "Dashboard";
            this.btnNavDashboard.Name = "btnNavDashboard";
            this.btnNavDashboard.TabIndex = 1;
            // 
            // btnNavProducts
            // 
            this.btnNavProducts.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavProducts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavProducts.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavProducts.FlatAppearance.BorderSize = 0;
            this.btnNavProducts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavProducts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavProducts.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavProducts.ForeColor = System.Drawing.Color.White;
            this.btnNavProducts.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavProducts.Size = new System.Drawing.Size(170, 46);
            this.btnNavProducts.Text = "Products";
            this.btnNavProducts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavProducts.UseVisualStyleBackColor = false;
            this.btnNavProducts.Tag = "Products";
            this.btnNavProducts.Name = "btnNavProducts";
            this.btnNavProducts.TabIndex = 2;
            // 
            // btnNavCategories
            // 
            this.btnNavCategories.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavCategories.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavCategories.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavCategories.FlatAppearance.BorderSize = 0;
            this.btnNavCategories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavCategories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavCategories.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavCategories.ForeColor = System.Drawing.Color.White;
            this.btnNavCategories.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavCategories.Size = new System.Drawing.Size(170, 46);
            this.btnNavCategories.Text = "Categories";
            this.btnNavCategories.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavCategories.UseVisualStyleBackColor = false;
            this.btnNavCategories.Tag = "Categories";
            this.btnNavCategories.Name = "btnNavCategories";
            this.btnNavCategories.TabIndex = 3;
            // 
            // btnNavSuppliers
            // 
            this.btnNavSuppliers.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavSuppliers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavSuppliers.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavSuppliers.FlatAppearance.BorderSize = 0;
            this.btnNavSuppliers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavSuppliers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavSuppliers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavSuppliers.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavSuppliers.ForeColor = System.Drawing.Color.White;
            this.btnNavSuppliers.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavSuppliers.Size = new System.Drawing.Size(170, 46);
            this.btnNavSuppliers.Text = "Suppliers";
            this.btnNavSuppliers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavSuppliers.UseVisualStyleBackColor = false;
            this.btnNavSuppliers.Tag = "Suppliers";
            this.btnNavSuppliers.Name = "btnNavSuppliers";
            this.btnNavSuppliers.TabIndex = 4;
            // 
            // btnNavTransaction
            // 
            this.btnNavTransaction.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavTransaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavTransaction.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavTransaction.FlatAppearance.BorderSize = 0;
            this.btnNavTransaction.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavTransaction.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavTransaction.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavTransaction.ForeColor = System.Drawing.Color.White;
            this.btnNavTransaction.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavTransaction.Size = new System.Drawing.Size(170, 46);
            this.btnNavTransaction.Text = "Transaction";
            this.btnNavTransaction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavTransaction.UseVisualStyleBackColor = false;
            this.btnNavTransaction.Tag = "Transaction";
            this.btnNavTransaction.Name = "btnNavTransaction";
            this.btnNavTransaction.TabIndex = 5;
            // 
            // btnNavReports
            // 
            this.btnNavReports.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavReports.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavReports.FlatAppearance.BorderSize = 0;
            this.btnNavReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavReports.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavReports.ForeColor = System.Drawing.Color.White;
            this.btnNavReports.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavReports.Size = new System.Drawing.Size(170, 46);
            this.btnNavReports.Text = "Reports";
            this.btnNavReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavReports.UseVisualStyleBackColor = false;
            this.btnNavReports.Tag = "Reports";
            this.btnNavReports.Name = "btnNavReports";
            this.btnNavReports.TabIndex = 6;
            // 
            // btnNavSettings
            // 
            this.btnNavSettings.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnNavSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNavSettings.FlatAppearance.BorderSize = 0;
            this.btnNavSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(74, 20, 140);
            this.btnNavSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavSettings.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnNavSettings.ForeColor = System.Drawing.Color.White;
            this.btnNavSettings.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.btnNavSettings.Size = new System.Drawing.Size(170, 46);
            this.btnNavSettings.Text = "Settings";
            this.btnNavSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavSettings.UseVisualStyleBackColor = false;
            this.btnNavSettings.Tag = "Settings";
            this.btnNavSettings.Name = "btnNavSettings";
            this.btnNavSettings.TabIndex = 7;
            // 
            // pnlSidebar
            // 
            this.pnlSidebar.Controls.Add(this.btnLogout);
            this.pnlSidebar.Controls.Add(this.btnNavSettings);
            this.pnlSidebar.Controls.Add(this.btnNavReports);
            this.pnlSidebar.Controls.Add(this.btnNavTransaction);
            this.pnlSidebar.Controls.Add(this.btnNavSuppliers);
            this.pnlSidebar.Controls.Add(this.btnNavCategories);
            this.pnlSidebar.Controls.Add(this.btnNavProducts);
            this.pnlSidebar.Controls.Add(this.btnNavDashboard);
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Padding = new System.Windows.Forms.Padding(0, 16, 0, 16);
            this.pnlSidebar.Size = new System.Drawing.Size(170, 680);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.TabIndex = 8;
            // 
            // lblTotalValue
            // 
            this.lblTotalValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblTotalValue.ForeColor = System.Drawing.Color.FromArgb(40, 40, 40);
            this.lblTotalValue.Size = new System.Drawing.Size(100, 60);
            this.lblTotalValue.Text = "0";
            this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTotalValue.Name = "lblTotalValue";
            this.lblTotalValue.TabIndex = 9;
            // 
            // lblTotalCaption
            // 
            this.lblTotalCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTotalCaption.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblTotalCaption.ForeColor = System.Drawing.Color.DimGray;
            this.lblTotalCaption.Size = new System.Drawing.Size(100, 28);
            this.lblTotalCaption.Text = "Total Products";
            this.lblTotalCaption.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblTotalCaption.Name = "lblTotalCaption";
            this.lblTotalCaption.TabIndex = 10;
            // 
            // cardTotalBody
            // 
            this.cardTotalBody.Controls.Add(this.lblTotalValue);
            this.cardTotalBody.Controls.Add(this.lblTotalCaption);
            this.cardTotalBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardTotalBody.Padding = new System.Windows.Forms.Padding(14, 8, 8, 8);
            this.cardTotalBody.Size = new System.Drawing.Size(100, 90);
            this.cardTotalBody.Name = "cardTotalBody";
            this.cardTotalBody.TabIndex = 11;
            // 
            // cardTotalStrip
            // 
            this.cardTotalStrip.BackColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.cardTotalStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardTotalStrip.Size = new System.Drawing.Size(5, 90);
            this.cardTotalStrip.Name = "cardTotalStrip";
            this.cardTotalStrip.TabIndex = 12;
            // 
            // cardTotal
            // 
            this.cardTotal.Controls.Add(this.cardTotalBody);
            this.cardTotal.Controls.Add(this.cardTotalStrip);
            this.cardTotal.BackColor = System.Drawing.Color.White;
            this.cardTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardTotal.Margin = new System.Windows.Forms.Padding(0, 0, 14, 0);
            this.cardTotal.Size = new System.Drawing.Size(100, 90);
            this.cardTotal.Name = "cardTotal";
            this.cardTotal.TabIndex = 13;
            // 
            // lblInStockValue
            // 
            this.lblInStockValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInStockValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblInStockValue.ForeColor = System.Drawing.Color.FromArgb(40, 40, 40);
            this.lblInStockValue.Size = new System.Drawing.Size(100, 60);
            this.lblInStockValue.Text = "0";
            this.lblInStockValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblInStockValue.Name = "lblInStockValue";
            this.lblInStockValue.TabIndex = 14;
            // 
            // lblInStockCaption
            // 
            this.lblInStockCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblInStockCaption.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblInStockCaption.ForeColor = System.Drawing.Color.DimGray;
            this.lblInStockCaption.Size = new System.Drawing.Size(100, 28);
            this.lblInStockCaption.Text = "In Stock";
            this.lblInStockCaption.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblInStockCaption.Name = "lblInStockCaption";
            this.lblInStockCaption.TabIndex = 15;
            // 
            // cardInStockBody
            // 
            this.cardInStockBody.Controls.Add(this.lblInStockValue);
            this.cardInStockBody.Controls.Add(this.lblInStockCaption);
            this.cardInStockBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardInStockBody.Padding = new System.Windows.Forms.Padding(14, 8, 8, 8);
            this.cardInStockBody.Size = new System.Drawing.Size(100, 90);
            this.cardInStockBody.Name = "cardInStockBody";
            this.cardInStockBody.TabIndex = 16;
            // 
            // cardInStockStrip
            // 
            this.cardInStockStrip.BackColor = System.Drawing.Color.FromArgb(46, 139, 87);
            this.cardInStockStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardInStockStrip.Size = new System.Drawing.Size(5, 90);
            this.cardInStockStrip.Name = "cardInStockStrip";
            this.cardInStockStrip.TabIndex = 17;
            // 
            // cardInStock
            // 
            this.cardInStock.Controls.Add(this.cardInStockBody);
            this.cardInStock.Controls.Add(this.cardInStockStrip);
            this.cardInStock.BackColor = System.Drawing.Color.White;
            this.cardInStock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardInStock.Margin = new System.Windows.Forms.Padding(0, 0, 14, 0);
            this.cardInStock.Size = new System.Drawing.Size(100, 90);
            this.cardInStock.Name = "cardInStock";
            this.cardInStock.TabIndex = 18;
            // 
            // lblLowStockValue
            // 
            this.lblLowStockValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLowStockValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblLowStockValue.ForeColor = System.Drawing.Color.FromArgb(40, 40, 40);
            this.lblLowStockValue.Size = new System.Drawing.Size(100, 60);
            this.lblLowStockValue.Text = "0";
            this.lblLowStockValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblLowStockValue.Name = "lblLowStockValue";
            this.lblLowStockValue.TabIndex = 19;
            // 
            // lblLowStockCaption
            // 
            this.lblLowStockCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblLowStockCaption.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblLowStockCaption.ForeColor = System.Drawing.Color.DimGray;
            this.lblLowStockCaption.Size = new System.Drawing.Size(100, 28);
            this.lblLowStockCaption.Text = "Low Stock";
            this.lblLowStockCaption.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblLowStockCaption.Name = "lblLowStockCaption";
            this.lblLowStockCaption.TabIndex = 20;
            // 
            // cardLowStockBody
            // 
            this.cardLowStockBody.Controls.Add(this.lblLowStockValue);
            this.cardLowStockBody.Controls.Add(this.lblLowStockCaption);
            this.cardLowStockBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardLowStockBody.Padding = new System.Windows.Forms.Padding(14, 8, 8, 8);
            this.cardLowStockBody.Size = new System.Drawing.Size(100, 90);
            this.cardLowStockBody.Name = "cardLowStockBody";
            this.cardLowStockBody.TabIndex = 21;
            // 
            // cardLowStockStrip
            // 
            this.cardLowStockStrip.BackColor = System.Drawing.Color.FromArgb(178, 34, 34);
            this.cardLowStockStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardLowStockStrip.Size = new System.Drawing.Size(5, 90);
            this.cardLowStockStrip.Name = "cardLowStockStrip";
            this.cardLowStockStrip.TabIndex = 22;
            // 
            // cardLowStock
            // 
            this.cardLowStock.Controls.Add(this.cardLowStockBody);
            this.cardLowStock.Controls.Add(this.cardLowStockStrip);
            this.cardLowStock.BackColor = System.Drawing.Color.White;
            this.cardLowStock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardLowStock.Margin = new System.Windows.Forms.Padding(0, 0, 14, 0);
            this.cardLowStock.Size = new System.Drawing.Size(100, 90);
            this.cardLowStock.Name = "cardLowStock";
            this.cardLowStock.TabIndex = 23;
            // 
            // lblSuppliersValue
            // 
            this.lblSuppliersValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSuppliersValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblSuppliersValue.ForeColor = System.Drawing.Color.FromArgb(40, 40, 40);
            this.lblSuppliersValue.Size = new System.Drawing.Size(100, 60);
            this.lblSuppliersValue.Text = "0";
            this.lblSuppliersValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSuppliersValue.Name = "lblSuppliersValue";
            this.lblSuppliersValue.TabIndex = 24;
            // 
            // lblSuppliersCaption
            // 
            this.lblSuppliersCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSuppliersCaption.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblSuppliersCaption.ForeColor = System.Drawing.Color.DimGray;
            this.lblSuppliersCaption.Size = new System.Drawing.Size(100, 28);
            this.lblSuppliersCaption.Text = "Total Suppliers";
            this.lblSuppliersCaption.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblSuppliersCaption.Name = "lblSuppliersCaption";
            this.lblSuppliersCaption.TabIndex = 25;
            // 
            // cardSuppliersBody
            // 
            this.cardSuppliersBody.Controls.Add(this.lblSuppliersValue);
            this.cardSuppliersBody.Controls.Add(this.lblSuppliersCaption);
            this.cardSuppliersBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardSuppliersBody.Padding = new System.Windows.Forms.Padding(14, 8, 8, 8);
            this.cardSuppliersBody.Size = new System.Drawing.Size(100, 90);
            this.cardSuppliersBody.Name = "cardSuppliersBody";
            this.cardSuppliersBody.TabIndex = 26;
            // 
            // cardSuppliersStrip
            // 
            this.cardSuppliersStrip.BackColor = System.Drawing.Color.FromArgb(70, 130, 180);
            this.cardSuppliersStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardSuppliersStrip.Size = new System.Drawing.Size(5, 90);
            this.cardSuppliersStrip.Name = "cardSuppliersStrip";
            this.cardSuppliersStrip.TabIndex = 27;
            // 
            // cardSuppliers
            // 
            this.cardSuppliers.Controls.Add(this.cardSuppliersBody);
            this.cardSuppliers.Controls.Add(this.cardSuppliersStrip);
            this.cardSuppliers.BackColor = System.Drawing.Color.White;
            this.cardSuppliers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardSuppliers.Margin = new System.Windows.Forms.Padding(0);
            this.cardSuppliers.Size = new System.Drawing.Size(100, 90);
            this.cardSuppliers.Name = "cardSuppliers";
            this.cardSuppliers.TabIndex = 28;
            // 
            // tblCards
            // 
            this.tblCards.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblCards.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblCards.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblCards.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblCards.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblCards.Controls.Add(this.cardTotal, 0, 0);
            this.tblCards.Controls.Add(this.cardInStock, 1, 0);
            this.tblCards.Controls.Add(this.cardLowStock, 2, 0);
            this.tblCards.Controls.Add(this.cardSuppliers, 3, 0);
            this.tblCards.ColumnCount = 4;
            this.tblCards.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblCards.RowCount = 1;
            this.tblCards.Size = new System.Drawing.Size(900, 94);
            this.tblCards.Name = "tblCards";
            this.tblCards.TabIndex = 29;
            // 
            // pnlCardsHost
            // 
            this.pnlCardsHost.Controls.Add(this.tblCards);
            this.pnlCardsHost.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCardsHost.Padding = new System.Windows.Forms.Padding(0, 0, 0, 14);
            this.pnlCardsHost.Size = new System.Drawing.Size(900, 108);
            this.pnlCardsHost.Name = "pnlCardsHost";
            this.pnlCardsHost.TabIndex = 30;
            // 
            // lblWelcome
            // 
            this.lblWelcome.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.lblWelcome.Size = new System.Drawing.Size(900, 46);
            this.lblWelcome.Text = "WELCOME!";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.TabIndex = 31;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            this.btnAddProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddProduct.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnAddProduct.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnAddProduct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnAddProduct.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnAddProduct.Size = new System.Drawing.Size(140, 36);
            this.btnAddProduct.Text = "+ Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.TabIndex = 32;
            // 
            // pnlAddHost
            // 
            this.pnlAddHost.Controls.Add(this.btnAddProduct);
            this.pnlAddHost.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlAddHost.Padding = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.pnlAddHost.Size = new System.Drawing.Size(140, 54);
            this.pnlAddHost.Name = "pnlAddHost";
            this.pnlAddHost.TabIndex = 33;
            // 
            // txtSearch
            // 
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSearch.PlaceholderText = "Search products...";
            this.txtSearch.Size = new System.Drawing.Size(270, 25);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.TabIndex = 34;
            // 
            // pnlSearchHost
            // 
            this.pnlSearchHost.Controls.Add(this.txtSearch);
            this.pnlSearchHost.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSearchHost.Padding = new System.Windows.Forms.Padding(0, 15, 0, 0);
            this.pnlSearchHost.Size = new System.Drawing.Size(270, 54);
            this.pnlSearchHost.Name = "pnlSearchHost";
            this.pnlSearchHost.TabIndex = 35;
            // 
            // lblProducts
            // 
            this.lblProducts.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblProducts.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.lblProducts.Size = new System.Drawing.Size(100, 54);
            this.lblProducts.Text = "Products";
            this.lblProducts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.TabIndex = 36;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.pnlSearchHost);
            this.pnlTop.Controls.Add(this.pnlAddHost);
            this.pnlTop.Controls.Add(this.lblProducts);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Size = new System.Drawing.Size(700, 54);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.TabIndex = 37;
            // 
            // colId
            // 
            this.colId.HeaderText = "ID";
            this.colId.Name = "colId";
            this.colId.FillWeight = 8F;
            this.colId.Name = "colId";
            // 
            // colName
            // 
            this.colName.HeaderText = "Product Name";
            this.colName.Name = "colName";
            this.colName.FillWeight = 24F;
            this.colName.Name = "colName";
            // 
            // colCategory
            // 
            this.colCategory.HeaderText = "Category";
            this.colCategory.Name = "colCategory";
            this.colCategory.FillWeight = 17F;
            this.colCategory.Name = "colCategory";
            // 
            // colStock
            // 
            this.colStock.HeaderText = "Stock";
            this.colStock.Name = "colStock";
            this.colStock.FillWeight = 10F;
            this.colStock.Name = "colStock";
            // 
            // colPrice
            // 
            this.colPrice.HeaderText = "Price";
            this.colPrice.Name = "colPrice";
            this.colPrice.FillWeight = 14F;
            this.colPrice.Name = "colPrice";
            // 
            // colSupplier
            // 
            this.colSupplier.HeaderText = "Supplier";
            this.colSupplier.Name = "colSupplier";
            this.colSupplier.FillWeight = 19F;
            this.colSupplier.Name = "colSupplier";
            // 
            // colEdit
            // 
            this.colEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colEdit.HeaderText = "Actions";
            this.colEdit.Name = "colEdit";
            this.colEdit.FillWeight = 9F;
            this.colEdit.Text = "Edit";
            this.colEdit.UseColumnTextForButtonValue = true;
            this.colEdit.Name = "colEdit";
            // 
            // colDelete
            // 
            this.colDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colDelete.HeaderText = "";
            this.colDelete.Name = "colDelete";
            this.colDelete.FillWeight = 10F;
            this.colDelete.Text = "Delete";
            this.colDelete.UseColumnTextForButtonValue = true;
            this.colDelete.Name = "colDelete";
            // 
            // grid
            // 
            gridHeaderStyle.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            gridHeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            gridHeaderStyle.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            gridHeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            gridHeaderStyle.SelectionForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            gridCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(232, 214, 240);
            gridCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.grid.RowTemplate.Height = 34;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colId, this.colName, this.colCategory, this.colStock, this.colPrice, this.colSupplier, this.colEdit, this.colDelete });
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.AllowUserToResizeRows = false;
            this.grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid.BackgroundColor = System.Drawing.Color.White;
            this.grid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.grid.ColumnHeadersDefaultCellStyle = gridHeaderStyle;
            this.grid.ColumnHeadersHeight = 38;
            this.grid.DefaultCellStyle = gridCellStyle;
            this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid.EnableHeadersVisualStyles = false;
            this.grid.GridColor = System.Drawing.Color.FromArgb(230, 225, 235);
            this.grid.MultiSelect = false;
            this.grid.ReadOnly = true;
            this.grid.RowHeadersVisible = false;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.Size = new System.Drawing.Size(670, 400);
            this.grid.Name = "grid";
            this.grid.TabIndex = 46;
            // 
            // pnlProducts
            // 
            this.pnlProducts.Controls.Add(this.grid);
            this.pnlProducts.Controls.Add(this.pnlTop);
            this.pnlProducts.BackColor = System.Drawing.Color.White;
            this.pnlProducts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProducts.Padding = new System.Windows.Forms.Padding(14);
            this.pnlProducts.Size = new System.Drawing.Size(700, 480);
            this.pnlProducts.Name = "pnlProducts";
            this.pnlProducts.TabIndex = 47;
            // 
            // btnQuickAdd
            // 
            this.btnQuickAdd.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            this.btnQuickAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuickAdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQuickAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuickAdd.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnQuickAdd.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickAdd.Size = new System.Drawing.Size(200, 42);
            this.btnQuickAdd.Text = "Add Product";
            this.btnQuickAdd.UseVisualStyleBackColor = false;
            this.btnQuickAdd.Name = "btnQuickAdd";
            this.btnQuickAdd.TabIndex = 48;
            // 
            // hostQuickAdd
            // 
            this.hostQuickAdd.Controls.Add(this.btnQuickAdd);
            this.hostQuickAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.hostQuickAdd.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.hostQuickAdd.Size = new System.Drawing.Size(200, 52);
            this.hostQuickAdd.Name = "hostQuickAdd";
            this.hostQuickAdd.TabIndex = 49;
            // 
            // btnQuickStockIn
            // 
            this.btnQuickStockIn.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            this.btnQuickStockIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuickStockIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQuickStockIn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickStockIn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickStockIn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickStockIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuickStockIn.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnQuickStockIn.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickStockIn.Size = new System.Drawing.Size(200, 42);
            this.btnQuickStockIn.Text = "Stock In";
            this.btnQuickStockIn.UseVisualStyleBackColor = false;
            this.btnQuickStockIn.Name = "btnQuickStockIn";
            this.btnQuickStockIn.TabIndex = 50;
            // 
            // hostQuickStockIn
            // 
            this.hostQuickStockIn.Controls.Add(this.btnQuickStockIn);
            this.hostQuickStockIn.Dock = System.Windows.Forms.DockStyle.Top;
            this.hostQuickStockIn.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.hostQuickStockIn.Size = new System.Drawing.Size(200, 52);
            this.hostQuickStockIn.Name = "hostQuickStockIn";
            this.hostQuickStockIn.TabIndex = 51;
            // 
            // btnQuickStockOut
            // 
            this.btnQuickStockOut.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            this.btnQuickStockOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuickStockOut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQuickStockOut.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickStockOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickStockOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickStockOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuickStockOut.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnQuickStockOut.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickStockOut.Size = new System.Drawing.Size(200, 42);
            this.btnQuickStockOut.Text = "Stock Out";
            this.btnQuickStockOut.UseVisualStyleBackColor = false;
            this.btnQuickStockOut.Name = "btnQuickStockOut";
            this.btnQuickStockOut.TabIndex = 52;
            // 
            // hostQuickStockOut
            // 
            this.hostQuickStockOut.Controls.Add(this.btnQuickStockOut);
            this.hostQuickStockOut.Dock = System.Windows.Forms.DockStyle.Top;
            this.hostQuickStockOut.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.hostQuickStockOut.Size = new System.Drawing.Size(200, 52);
            this.hostQuickStockOut.Name = "hostQuickStockOut";
            this.hostQuickStockOut.TabIndex = 53;
            // 
            // btnQuickReport
            // 
            this.btnQuickReport.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            this.btnQuickReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuickReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQuickReport.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(225, 200, 235);
            this.btnQuickReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuickReport.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnQuickReport.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.btnQuickReport.Size = new System.Drawing.Size(200, 42);
            this.btnQuickReport.Text = "System.Windows.Forms.View Report";
            this.btnQuickReport.UseVisualStyleBackColor = false;
            this.btnQuickReport.Name = "btnQuickReport";
            this.btnQuickReport.TabIndex = 54;
            // 
            // hostQuickReport
            // 
            this.hostQuickReport.Controls.Add(this.btnQuickReport);
            this.hostQuickReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.hostQuickReport.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.hostQuickReport.Size = new System.Drawing.Size(200, 52);
            this.hostQuickReport.Name = "hostQuickReport";
            this.hostQuickReport.TabIndex = 55;
            // 
            // lblQuick
            // 
            this.lblQuick.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblQuick.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblQuick.Size = new System.Drawing.Size(200, 40);
            this.lblQuick.Text = "Quick Actions";
            this.lblQuick.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblQuick.Name = "lblQuick";
            this.lblQuick.TabIndex = 56;
            // 
            // pnlQuick
            // 
            this.pnlQuick.Controls.Add(this.hostQuickReport);
            this.pnlQuick.Controls.Add(this.hostQuickStockOut);
            this.pnlQuick.Controls.Add(this.hostQuickStockIn);
            this.pnlQuick.Controls.Add(this.hostQuickAdd);
            this.pnlQuick.Controls.Add(this.lblQuick);
            this.pnlQuick.BackColor = System.Drawing.Color.White;
            this.pnlQuick.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlQuick.Padding = new System.Windows.Forms.Padding(14);
            this.pnlQuick.Size = new System.Drawing.Size(250, 260);
            this.pnlQuick.Name = "pnlQuick";
            this.pnlQuick.TabIndex = 57;
            // 
            // colLowName
            // 
            this.colLowName.Text = "Product";
            this.colLowName.Width = 140;
            this.colLowName.Name = "colLowName";
            // 
            // colLowStock
            // 
            this.colLowStock.Text = "Stock";
            this.colLowStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colLowStock.Width = 70;
            this.colLowStock.Name = "colLowStock";
            // 
            // lowList
            // 
            this.lowList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colLowName, this.colLowStock });
            this.lowList.Activation = System.Windows.Forms.ItemActivation.Standard;
            this.lowList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lowList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lowList.FullRowSelect = true;
            this.lowList.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lowList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lowList.Size = new System.Drawing.Size(220, 150);
            this.lowList.UseCompatibleStateImageBehavior = false;
            this.lowList.View = System.Windows.Forms.View.Details;
            this.lowList.Name = "lowList";
            this.lowList.TabIndex = 60;
            // 
            // lblLowTitle
            // 
            this.lblLowTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLowTitle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblLowTitle.ForeColor = System.Drawing.Color.Firebrick;
            this.lblLowTitle.Size = new System.Drawing.Size(160, 32);
            this.lblLowTitle.Text = "Low Stock Alert!";
            this.lblLowTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblLowTitle.Name = "lblLowTitle";
            this.lblLowTitle.TabIndex = 61;
            // 
            // linkViewAll
            // 
            this.linkViewAll.Dock = System.Windows.Forms.DockStyle.Right;
            this.linkViewAll.LinkColor = System.Drawing.Color.FromArgb(106, 27, 154);
            this.linkViewAll.Size = new System.Drawing.Size(60, 32);
            this.linkViewAll.Text = "view all";
            this.linkViewAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkViewAll.Name = "linkViewAll";
            this.linkViewAll.TabIndex = 62;
            // 
            // pnlLowHeader
            // 
            this.pnlLowHeader.Controls.Add(this.lblLowTitle);
            this.pnlLowHeader.Controls.Add(this.linkViewAll);
            this.pnlLowHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLowHeader.Size = new System.Drawing.Size(220, 32);
            this.pnlLowHeader.Name = "pnlLowHeader";
            this.pnlLowHeader.TabIndex = 63;
            // 
            // pnlLow
            // 
            this.pnlLow.Controls.Add(this.lowList);
            this.pnlLow.Controls.Add(this.pnlLowHeader);
            this.pnlLow.BackColor = System.Drawing.Color.White;
            this.pnlLow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLow.Padding = new System.Windows.Forms.Padding(14, 10, 14, 10);
            this.pnlLow.Size = new System.Drawing.Size(250, 200);
            this.pnlLow.Name = "pnlLow";
            this.pnlLow.TabIndex = 64;
            // 
            // pnlLowHost
            // 
            this.pnlLowHost.Controls.Add(this.pnlLow);
            this.pnlLowHost.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLowHost.Padding = new System.Windows.Forms.Padding(0, 0, 0, 12);
            this.pnlLowHost.Size = new System.Drawing.Size(250, 214);
            this.pnlLowHost.Name = "pnlLowHost";
            this.pnlLowHost.TabIndex = 65;
            // 
            // pnlRight
            // 
            this.pnlRight.Controls.Add(this.pnlQuick);
            this.pnlRight.Controls.Add(this.pnlLowHost);
            this.pnlRight.BackColor = System.Drawing.Color.FromArgb(245, 243, 247);
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlRight.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlRight.Size = new System.Drawing.Size(262, 480);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.TabIndex = 66;
            // 
            // pnlBody
            // 
            this.pnlBody.Controls.Add(this.pnlProducts);
            this.pnlBody.Controls.Add(this.pnlRight);
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Size = new System.Drawing.Size(900, 480);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.TabIndex = 67;
            // 
            // viewDashboard
            // 
            this.viewDashboard.Controls.Add(this.pnlBody);
            this.viewDashboard.Controls.Add(this.pnlCardsHost);
            this.viewDashboard.Controls.Add(this.lblWelcome);
            this.viewDashboard.BackColor = System.Drawing.Color.FromArgb(245, 243, 247);
            this.viewDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewDashboard.Size = new System.Drawing.Size(900, 648);
            this.viewDashboard.Name = "viewDashboard";
            this.viewDashboard.TabIndex = 68;
            // 
            // tableGrid
            // 
            tableGridHeaderStyle.BackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            tableGridHeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            tableGridHeaderStyle.ForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            tableGridHeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(243, 229, 245);
            tableGridHeaderStyle.SelectionForeColor = System.Drawing.Color.FromArgb(106, 27, 154);
            tableGridCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(232, 214, 240);
            tableGridCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.tableGrid.RowTemplate.Height = 34;
            this.tableGrid.AllowUserToAddRows = false;
            this.tableGrid.AllowUserToDeleteRows = false;
            this.tableGrid.AllowUserToResizeRows = false;
            this.tableGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tableGrid.BackgroundColor = System.Drawing.Color.White;
            this.tableGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tableGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.tableGrid.ColumnHeadersDefaultCellStyle = tableGridHeaderStyle;
            this.tableGrid.ColumnHeadersHeight = 38;
            this.tableGrid.DefaultCellStyle = tableGridCellStyle;
            this.tableGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableGrid.EnableHeadersVisualStyles = false;
            this.tableGrid.GridColor = System.Drawing.Color.FromArgb(230, 225, 235);
            this.tableGrid.MultiSelect = false;
            this.tableGrid.ReadOnly = true;
            this.tableGrid.RowHeadersVisible = false;
            this.tableGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tableGrid.Size = new System.Drawing.Size(670, 400);
            this.tableGrid.Name = "tableGrid";
            this.tableGrid.TabIndex = 69;
            // 
            // lblTableTitle
            // 
            this.lblTableTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTableTitle.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.lblTableTitle.Size = new System.Drawing.Size(868, 46);
            this.lblTableTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTableTitle.Name = "lblTableTitle";
            this.lblTableTitle.TabIndex = 70;
            // 
            // viewTable
            // 
            this.viewTable.Controls.Add(this.tableGrid);
            this.viewTable.Controls.Add(this.lblTableTitle);
            this.viewTable.BackColor = System.Drawing.Color.White;
            this.viewTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewTable.Padding = new System.Windows.Forms.Padding(16);
            this.viewTable.Size = new System.Drawing.Size(900, 648);
            this.viewTable.Visible = false;
            this.viewTable.Name = "viewTable";
            this.viewTable.TabIndex = 71;
            // 
            // pnlContent
            // 
            this.pnlContent.Controls.Add(this.viewDashboard);
            this.pnlContent.Controls.Add(this.viewTable);
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(245, 243, 247);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Padding = new System.Windows.Forms.Padding(16);
            this.pnlContent.Size = new System.Drawing.Size(950, 680);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.TabIndex = 72;
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(245, 243, 247);
            this.ClientSize = new System.Drawing.Size(1120, 680);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlSidebar);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory Management System";
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableGrid)).EndInit();
            this.pnlSidebar.ResumeLayout(false);
            this.cardTotalBody.ResumeLayout(false);
            this.cardTotal.ResumeLayout(false);
            this.cardInStockBody.ResumeLayout(false);
            this.cardInStock.ResumeLayout(false);
            this.cardLowStockBody.ResumeLayout(false);
            this.cardLowStock.ResumeLayout(false);
            this.cardSuppliersBody.ResumeLayout(false);
            this.cardSuppliers.ResumeLayout(false);
            this.tblCards.ResumeLayout(false);
            this.pnlCardsHost.ResumeLayout(false);
            this.pnlAddHost.ResumeLayout(false);
            this.pnlSearchHost.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlProducts.ResumeLayout(false);
            this.hostQuickAdd.ResumeLayout(false);
            this.hostQuickStockIn.ResumeLayout(false);
            this.hostQuickStockOut.ResumeLayout(false);
            this.hostQuickReport.ResumeLayout(false);
            this.pnlQuick.ResumeLayout(false);
            this.pnlLowHeader.ResumeLayout(false);
            this.pnlLow.ResumeLayout(false);
            this.pnlLowHost.ResumeLayout(false);
            this.pnlRight.ResumeLayout(false);
            this.pnlBody.ResumeLayout(false);
            this.viewDashboard.ResumeLayout(false);
            this.viewTable.ResumeLayout(false);
            this.pnlContent.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnNavDashboard;
        private System.Windows.Forms.Button btnNavProducts;
        private System.Windows.Forms.Button btnNavCategories;
        private System.Windows.Forms.Button btnNavSuppliers;
        private System.Windows.Forms.Button btnNavTransaction;
        private System.Windows.Forms.Button btnNavReports;
        private System.Windows.Forms.Button btnNavSettings;
        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Label lblTotalValue;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Panel cardTotalBody;
        private System.Windows.Forms.Panel cardTotalStrip;
        private System.Windows.Forms.Panel cardTotal;
        private System.Windows.Forms.Label lblInStockValue;
        private System.Windows.Forms.Label lblInStockCaption;
        private System.Windows.Forms.Panel cardInStockBody;
        private System.Windows.Forms.Panel cardInStockStrip;
        private System.Windows.Forms.Panel cardInStock;
        private System.Windows.Forms.Label lblLowStockValue;
        private System.Windows.Forms.Label lblLowStockCaption;
        private System.Windows.Forms.Panel cardLowStockBody;
        private System.Windows.Forms.Panel cardLowStockStrip;
        private System.Windows.Forms.Panel cardLowStock;
        private System.Windows.Forms.Label lblSuppliersValue;
        private System.Windows.Forms.Label lblSuppliersCaption;
        private System.Windows.Forms.Panel cardSuppliersBody;
        private System.Windows.Forms.Panel cardSuppliersStrip;
        private System.Windows.Forms.Panel cardSuppliers;
        private System.Windows.Forms.TableLayoutPanel tblCards;
        private System.Windows.Forms.Panel pnlCardsHost;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Panel pnlAddHost;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Panel pnlSearchHost;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSupplier;
        private System.Windows.Forms.DataGridViewButtonColumn colEdit;
        private System.Windows.Forms.DataGridViewButtonColumn colDelete;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.Panel pnlProducts;
        private System.Windows.Forms.Button btnQuickAdd;
        private System.Windows.Forms.Panel hostQuickAdd;
        private System.Windows.Forms.Button btnQuickStockIn;
        private System.Windows.Forms.Panel hostQuickStockIn;
        private System.Windows.Forms.Button btnQuickStockOut;
        private System.Windows.Forms.Panel hostQuickStockOut;
        private System.Windows.Forms.Button btnQuickReport;
        private System.Windows.Forms.Panel hostQuickReport;
        private System.Windows.Forms.Label lblQuick;
        private System.Windows.Forms.Panel pnlQuick;
        private System.Windows.Forms.ColumnHeader colLowName;
        private System.Windows.Forms.ColumnHeader colLowStock;
        private System.Windows.Forms.ListView lowList;
        private System.Windows.Forms.Label lblLowTitle;
        private System.Windows.Forms.LinkLabel linkViewAll;
        private System.Windows.Forms.Panel pnlLowHeader;
        private System.Windows.Forms.Panel pnlLow;
        private System.Windows.Forms.Panel pnlLowHost;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.Panel viewDashboard;
        private System.Windows.Forms.DataGridView tableGrid;
        private System.Windows.Forms.Label lblTableTitle;
        private System.Windows.Forms.Panel viewTable;
        private System.Windows.Forms.Panel pnlContent;
    }
}
