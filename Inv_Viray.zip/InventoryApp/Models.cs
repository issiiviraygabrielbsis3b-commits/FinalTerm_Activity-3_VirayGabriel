namespace InventoryApp;

public record User(string Username, string FullName)
{
    public string DisplayName => string.IsNullOrWhiteSpace(FullName) ? Username : FullName;
}

public class UserAccount
{
    public string Username { get; set; } = "";
    public string FullName { get; set; } = "";
    public string PasswordHash { get; set; } = "";
}
