namespace InventoryApp;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) =>
            MessageBox.Show(e.Exception.Message, "Inventory Management System",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

        
        while (true)
        {
            using var login = new SignInForm();
            if (login.ShowDialog() != DialogResult.OK || login.LoggedInUser is null)
                break;

            using var main = new DashboardForm(login.LoggedInUser);
            main.ShowDialog();
            if (!main.LoggedOut)
                break;
        }
    }
}
