namespace InventoryApp
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlBanner = new Panel();
            lblSubtitle = new Label();
            lblTitle = new Label();
            lblFullName = new Label();
            txtFullName = new TextBox();
            lblUser = new Label();
            txtUser = new TextBox();
            lblPass = new Label();
            txtPass = new TextBox();
            lblConfirm = new Label();
            txtConfirm = new TextBox();
            btnRegister = new Button();
            btnCancel = new Button();
            pnlBanner.SuspendLayout();
            SuspendLayout();
            // 
            // pnlBanner
            // 
            pnlBanner.BackColor = Color.FromArgb(106, 27, 154);
            pnlBanner.Controls.Add(lblSubtitle);
            pnlBanner.Controls.Add(lblTitle);
            pnlBanner.Dock = DockStyle.Top;
            pnlBanner.Location = new Point(0, 0);
            pnlBanner.Name = "pnlBanner";
            pnlBanner.Size = new Size(340, 90);
            pnlBanner.TabIndex = 0;
            // 
            // lblSubtitle
            // 
            lblSubtitle.AutoSize = true;
            lblSubtitle.BackColor = Color.Transparent;
            lblSubtitle.ForeColor = Color.FromArgb(243, 229, 245);
            lblSubtitle.Location = new Point(22, 54);
            lblSubtitle.Name = "lblSubtitle";
            lblSubtitle.Size = new Size(255, 17);
            lblSubtitle.TabIndex = 1;
            lblSubtitle.Text = "Register to Inventory Management System";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.BackColor = Color.Transparent;
            lblTitle.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(20, 14);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(173, 31);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Create account";
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Location = new Point(30, 110);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(63, 17);
            lblFullName.TabIndex = 1;
            lblFullName.Text = "Full name";
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(30, 130);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(280, 24);
            txtFullName.TabIndex = 2;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Location = new Point(30, 165);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(67, 17);
            lblUser.TabIndex = 3;
            lblUser.Text = "Username";
            // 
            // txtUser
            // 
            txtUser.Location = new Point(30, 185);
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(280, 24);
            txtUser.TabIndex = 4;
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Location = new Point(30, 220);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(172, 17);
            lblPass.TabIndex = 5;
            lblPass.Text = "Password (min 6 characters)";
            // 
            // txtPass
            // 
            txtPass.Location = new Point(30, 240);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(280, 24);
            txtPass.TabIndex = 6;
            txtPass.UseSystemPasswordChar = true;
            // 
            // lblConfirm
            // 
            lblConfirm.AutoSize = true;
            lblConfirm.Location = new Point(30, 275);
            lblConfirm.Name = "lblConfirm";
            lblConfirm.Size = new Size(115, 17);
            lblConfirm.TabIndex = 7;
            lblConfirm.Text = "Confirm password";
            // 
            // txtConfirm
            // 
            txtConfirm.Location = new Point(30, 295);
            txtConfirm.Name = "txtConfirm";
            txtConfirm.Size = new Size(280, 24);
            txtConfirm.TabIndex = 8;
            txtConfirm.UseSystemPasswordChar = true;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.FromArgb(106, 27, 154);
            btnRegister.Cursor = Cursors.Hand;
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.FlatAppearance.MouseDownBackColor = Color.FromArgb(74, 20, 140);
            btnRegister.FlatAppearance.MouseOverBackColor = Color.FromArgb(171, 71, 188);
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.ForeColor = Color.White;
            btnRegister.Location = new Point(30, 340);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(280, 38);
            btnRegister.TabIndex = 9;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.White;
            btnCancel.Cursor = Cursors.Hand;
            btnCancel.DialogResult = DialogResult.Cancel;
            btnCancel.FlatAppearance.BorderColor = Color.FromArgb(106, 27, 154);
            btnCancel.FlatAppearance.MouseDownBackColor = Color.FromArgb(243, 229, 245);
            btnCancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(243, 229, 245);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.ForeColor = Color.FromArgb(106, 27, 154);
            btnCancel.Location = new Point(30, 387);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(280, 32);
            btnCancel.TabIndex = 10;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            // 
            // RegisterForm
            // 
            AcceptButton = btnRegister;
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(250, 245, 252);
            CancelButton = btnCancel;
            ClientSize = new Size(340, 440);
            Controls.Add(btnCancel);
            Controls.Add(btnRegister);
            Controls.Add(txtConfirm);
            Controls.Add(lblConfirm);
            Controls.Add(txtPass);
            Controls.Add(lblPass);
            Controls.Add(txtUser);
            Controls.Add(lblUser);
            Controls.Add(txtFullName);
            Controls.Add(lblFullName);
            Controls.Add(pnlBanner);
            Font = new Font("Segoe UI", 9.5F);
            ForeColor = Color.FromArgb(49, 27, 71);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "RegisterForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Inventory System - Register";
            Load += RegisterForm_Load;
            pnlBanner.ResumeLayout(false);
            pnlBanner.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlBanner;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label lblConfirm;
        private System.Windows.Forms.TextBox txtConfirm;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCancel;
    }
}
