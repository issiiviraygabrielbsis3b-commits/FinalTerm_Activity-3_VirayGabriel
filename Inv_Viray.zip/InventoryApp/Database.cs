using System.Data.OleDb;
using System.Runtime.InteropServices;
using System.Text.Json;

namespace InventoryApp;





internal static class JsonStore
{
    private static readonly string Folder =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "InventoryApp");

    public static List<T> Load<T>(string fileName)
    {
        var path = Path.Combine(Folder, fileName);
        if (!File.Exists(path)) return new List<T>();
        try
        {
            return JsonSerializer.Deserialize<List<T>>(File.ReadAllText(path)) ?? new List<T>();
        }
        catch (JsonException)
        {
            return new List<T>();
        }
    }
}









internal static class Db
{
    private static readonly string AppDataFolder =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "InventoryApp");

    private static readonly string Folder = FindProjectFolder() ?? AppDataFolder;

    public static readonly string FilePath = Path.Combine(Folder, "viray_inventory.accdb");

    
    private static string? FindProjectFolder()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir is not null)
        {
            if (File.Exists(Path.Combine(dir.FullName, "InventoryApp.csproj"))) return dir.FullName;
            dir = dir.Parent;
        }
        return null;
    }

    private static readonly string[] Providers = { "Microsoft.ACE.OLEDB.16.0", "Microsoft.ACE.OLEDB.12.0" };
    private static readonly object Gate = new();
    private static string? _connectionString;

    public static OleDbConnection Open()
    {
        var conn = new OleDbConnection(GetConnectionString());
        conn.Open();
        return conn;
    }

    public static OleDbCommand Command(OleDbConnection conn, string sql, params (OleDbType Type, object? Value)[] args)
    {
        var cmd = new OleDbCommand(sql, conn);
        foreach (var (type, value) in args)
            cmd.Parameters.Add(new OleDbParameter { OleDbType = type, Value = value ?? DBNull.Value });
        return cmd;
    }

    public static string Str(OleDbDataReader r, int i) => r.IsDBNull(i) ? "" : r.GetString(i);

    private static string GetConnectionString()
    {
        lock (Gate)
        {
            if (_connectionString is not null) return _connectionString;

            Directory.CreateDirectory(Folder);

            string? chosen = null;
            var created = false;
            Exception? last = null;
            var errors = new System.Text.StringBuilder();

            foreach (var provider in Providers)
            {
                var cs = $"Provider={provider};Data Source={FilePath};";
                var stage = "start";
                var existedBefore = File.Exists(FilePath);
                try
                {
                    if (!existedBefore)
                    {
                        stage = "create file";
                        CreateFile(cs);
                        created = true;
                    }
                    stage = "open file";
                    using (var test = new OleDbConnection(cs)) test.Open();
                    chosen = cs;
                    break;
                }
                catch (Exception ex)
                {
                    last = ex;
                    var inner = ex.InnerException is null ? "" : " / " + ex.InnerException.Message;
                    errors.AppendLine($"- {provider} [{stage}]: {ex.GetType().Name}: {ex.Message}{inner}");
                    
                    if (!existedBefore) TryDeleteFile();
                    created = false;
                }
            }

            if (chosen is null)
            {
                throw new InvalidOperationException(
                    "Cannot open the Microsoft Access database.\n\n" +
                    "This app is running as " + (Environment.Is64BitProcess ? "64-bit" : "32-bit") + ". " +
                    "ACE providers found: " + DescribeProviders() + "\n\n" +
                    "If the provider list is empty or the bitness does not match, install the matching " +
                    "\"Microsoft Access Database Engine\" or change PlatformTarget in InventoryApp.csproj (x64 / x86).\n\n" +
                    "Details:\n" + errors + "\nFile: " + FilePath, last);
            }

            if (created)
            {
                try
                {
                    using var conn = new OleDbConnection(chosen);
                    conn.Open();
                    CreateSchema(conn);
                    MigrateFromJson(conn);
                }
                catch
                {
                    TryDeleteFile(); 
                    throw;
                }
            }

            _connectionString = chosen;
            return chosen;
        }
    }

    private static string DescribeProviders()
    {
        try
        {
            var enumerator = new OleDbEnumerator();
            var names = enumerator.GetElements().Rows.Cast<System.Data.DataRow>()
                .Select(r => r["SOURCES_NAME"]?.ToString() ?? "")
                .Where(n => n.Contains("ACE", StringComparison.OrdinalIgnoreCase))
                .ToList();
            return names.Count == 0 ? "none" : string.Join(", ", names);
        }
        catch (Exception ex)
        {
            return "unknown (" + ex.Message + ")";
        }
    }

    private static void CreateFile(string connectionString)
    {
        var type = Type.GetTypeFromProgID("ADOX.Catalog")
                   ?? throw new InvalidOperationException("ADOX (needed to create the Access file) is not available.");
        dynamic catalog = Activator.CreateInstance(type)!;
        try
        {
            catalog.Create(connectionString);
        }
        finally
        {
            Marshal.FinalReleaseComObject(catalog);
        }
    }

    private static void TryDeleteFile()
    {
        try
        {
            OleDbConnection.ReleaseObjectPool();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            if (File.Exists(FilePath)) File.Delete(FilePath);
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static void CreateSchema(OleDbConnection conn)
    {
        using var cmd = new OleDbCommand(
            "CREATE TABLE Users (Username TEXT(100) NOT NULL PRIMARY KEY, FullName TEXT(150), PasswordHash LONGTEXT)", conn);
        cmd.ExecuteNonQuery();
    }

    private static void MigrateFromJson(OleDbConnection conn)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var u in JsonStore.Load<UserAccount>("users.json"))
        {
            if (!seen.Add(u.Username)) continue;
            using var cmd = Command(conn, "INSERT INTO Users (Username, FullName, PasswordHash) VALUES (?, ?, ?)",
                (OleDbType.VarWChar, u.Username), (OleDbType.VarWChar, u.FullName), (OleDbType.LongVarWChar, u.PasswordHash));
            cmd.ExecuteNonQuery();
        }
    }
}
